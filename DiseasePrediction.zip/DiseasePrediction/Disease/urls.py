from django.urls import path,include
from . import views
from rest_framework import routers
from Disease.views import HomeView
from django.views.generic.base import RedirectView

router=routers.DefaultRouter()
router.register('Disease',views.ApprovalsView)
urlpatterns = [
    path('form/', views.myform),
    path('result', views.result),
    path('api/',include(router.urls)),
    path('home/', HomeView.as_view()),
    path('', RedirectView.as_view(url='home/')),
]
