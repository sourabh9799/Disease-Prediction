#Main url
from django.contrib import admin
from django.urls import path,include
from Disease import views


urlpatterns = [
    path('accounts/', include('registration.backends.default.urls')),
    path('admin/', admin.site.urls),
    path('', include('Disease.urls')),
]
